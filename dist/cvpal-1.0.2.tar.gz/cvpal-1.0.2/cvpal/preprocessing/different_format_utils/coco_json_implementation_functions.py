
def merge_data_json(self, path, paths, parental_reference):
    pass
