from cvpal.preprocessing import ImagesDetection
from cvpal.generate import DetectionDataset